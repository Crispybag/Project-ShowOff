﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sharedCool
{
    class Class1
    {
        static void Main()
        {
            //idk what to do here, but VS complains without it :)
        }
    }
}
